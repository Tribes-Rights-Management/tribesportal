import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";

/**
 * WORKSPACE CONTEXT BAR — OPERATIONAL CONFIRMATION
 * 
 * ═══════════════════════════════════════════════════════════════════════════
 * CANONICAL ARCHITECTURE ENFORCEMENT
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * This component renders a subtle confirmation line when user is operating
 * inside a workspace. It communicates:
 * - Active workspace context
 * - Current operational surface
 * 
 * RULES:
 * - Only renders inside workspaces (not System Console)
 * - Subtle, non-intrusive - part of the page header area
 * - Reinforces that user has transitioned to operational mode
 * ═══════════════════════════════════════════════════════════════════════════
 */

type ContextLabel = "Licensing" | "Tribes Admin" | "Publishing";

function getContextLabel(pathname: string): ContextLabel {
  if (pathname.startsWith("/licensing")) return "Licensing";
  if (pathname.startsWith("/portal")) return "Tribes Admin";
  return "Publishing";
}

export function WorkspaceContextBar() {
  const { activeTenant } = useAuth();
  const location = useLocation();
  
  // Don't render without active workspace or in system console
  if (!activeTenant || location.pathname.startsWith("/admin") || location.pathname.startsWith("/auditor")) {
    return null;
  }
  
  const contextLabel = getContextLabel(location.pathname);

  return (
    <div 
      className={cn(
        "md:px-6 py-2.5 border-b",
        "flex items-center justify-between gap-3"
      )}
      style={{
        backgroundColor: 'var(--tribes-surface)',
        borderColor: 'var(--tribes-border)',
        minHeight: '44px', // Mobile tap target
        paddingLeft: '20px',
        paddingRight: '20px',
      }}
    >
      {/* Context confirmation */}
      <p 
        className="text-[12px] leading-[1.4] min-w-0 flex-1"
        style={{ color: 'var(--tribes-fg-secondary)' }}
      >
        <span className="hidden sm:inline">You are operating inside the </span>
        <span 
          className="font-medium whitespace-nowrap"
          style={{ color: 'var(--tribes-fg)' }}
        >
          {contextLabel}
        </span>
        <span className="hidden sm:inline"> workspace.</span>
        <span className="sm:hidden"> workspace</span>
      </p>
      
      {/* Workspace name - subtle, desktop only */}
      <span 
        className="text-[11px] font-medium uppercase tracking-wider truncate max-w-[150px] hidden md:block shrink-0"
        style={{ color: 'var(--tribes-fg-muted)' }}
      >
        {activeTenant.tenant_name}
      </span>
    </div>
  );
}
