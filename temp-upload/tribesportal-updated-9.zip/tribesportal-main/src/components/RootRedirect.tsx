import { Navigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useRoleAccess } from "@/hooks/useRoleAccess";

/**
 * Smart redirect component for the root route.
 * Routes to appropriate destination based on access state and role.
 */
export default function RootRedirect() {
  const { accessState, activeContext, isPlatformAdmin } = useAuth();
  const { isExternalAuditor } = useRoleAccess();

  // SAFETY: Loading — ALWAYS render something, never return null
  if (accessState === "loading") {
    return (
      <div 
        className="min-h-screen flex items-center justify-center"
        style={{ backgroundColor: 'var(--app-bg)' }}
      >
        <p className="text-[14px]" style={{ color: 'var(--text-muted)' }}>
          Loading data
        </p>
      </div>
    );
  }

  // Not authenticated
  if (accessState === "unauthenticated") {
    return <Navigate to="/sign-in" replace />;
  }

  // No profile or suspended profile
  if (accessState === "no-profile" || accessState === "suspended-profile") {
    return <Navigate to="/auth/error" replace />;
  }

  // External auditor goes to auditor landing
  if (isExternalAuditor) {
    return <Navigate to="/auditor" replace />;
  }

  // All authenticated users (admin or not) go to Modules Home
  // Route based on access state
  switch (accessState) {
    case "no-access-request":
      return <Navigate to="/auth/unauthorized" replace />;
    case "pending-approval":
      return <Navigate to="/auth/unauthorized" replace />;
    case "suspended-access":
      return <Navigate to="/app/suspended" replace />;
    case "active":
      // All users land on Modules Home
      return <Navigate to="/workspaces" replace />;
    default:
      return <Navigate to="/sign-in" replace />;
  }
}
