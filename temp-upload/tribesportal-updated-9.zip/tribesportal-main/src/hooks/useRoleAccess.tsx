import React, { useMemo } from "react";
import { useAuth, PortalRole, PortalContext, PlatformRole } from "@/contexts/AuthContext";

/**
 * ROLE-BASED ACCESS HOOK — INSTITUTIONAL SURFACE PRUNING
 * 
 * ═══════════════════════════════════════════════════════════════════════════
 * MASTER ENFORCEMENT DIRECTIVE — LOCKED ARCHITECTURE
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * HIERARCHY (TWO LAYERS ONLY):
 * 
 * 1) COMPANY LAYER (NOT A WORKSPACE):
 *    • System Console — governance, audit, compliance, security
 *    • Access: platform_owner, external_auditor (read-only)
 *    • NO workspace selector, NO product navigation
 * 
 * 2) WORKSPACE LAYER (OPERATING ENVIRONMENTS):
 *    • Tribes Team — internal operations
 *    • Licensing — external licensees
 *    • Tribes Admin — administration clients
 * 
 * ROLE HIERARCHY:
 * 
 * COMPANY-LEVEL ROLES:
 * - platform_owner: Full System Console access, optional workspace access
 * - external_auditor: Read-only System Console, read-only approved workspace views
 * 
 * WORKSPACE ROLES:
 * - tribes_team_admin: Internal operations admin
 * - tribes_team_staff: Internal operations staff
 * - licensing_user: External licensee
 * - portal_client_admin: Tribes Admin client admin
 * - portal_client_user: Tribes Admin client user
 * 
 * RULES:
 * - Default deny
 * - All routes guarded (Access restricted, never 404)
 * - All privileged actions logged immutably
 * - RLS enforced by workspace + role
 * ═══════════════════════════════════════════════════════════════════════════
 */

export type Permission =
  // ═══════════════════════════════════════════════════════════════════════════
  // COMPANY-LEVEL PERMISSIONS (System Console only)
  // ═══════════════════════════════════════════════════════════════════════════
  | "platform:admin"
  | "platform:owner"           // Executive access
  | "platform:manage_users"
  | "platform:manage_tenants"
  | "platform:view_audit_logs"
  | "platform:manage_security"
  | "platform:view_governance"
  | "platform:view_disclosures"
  | "platform:cross_workspace_read"
  | "platform:manage_help"     // Help backend access (capability-based)
  
  // ═══════════════════════════════════════════════════════════════════════════
  // EXTERNAL AUDITOR PERMISSIONS (read-only)
  // ═══════════════════════════════════════════════════════════════════════════
  | "auditor:view_logs"
  | "auditor:view_licensing"
  | "auditor:view_agreements"
  | "auditor:view_disclosures"
  
  // ═══════════════════════════════════════════════════════════════════════════
  // WORKSPACE PERMISSIONS — TRIBES TEAM (internal operations)
  // ═══════════════════════════════════════════════════════════════════════════
  | "tribes_team:admin"
  | "tribes_team:review"       // Review and approve requests
  | "tribes_team:queues"       // Operational queues
  | "tribes_team:messaging"    // Internal messaging
  
  // ═══════════════════════════════════════════════════════════════════════════
  // WORKSPACE PERMISSIONS — LICENSING (external licensees)
  // ═══════════════════════════════════════════════════════════════════════════
  | "licensing.view"           // View licensing module and data
  | "licensing.manage"         // Create/edit licensing requests and agreements
  | "licensing.approve"        // Approve/reject licensing requests
  | "licensing.submit"         // Submit licensing requests
  
  // ═══════════════════════════════════════════════════════════════════════════
  // WORKSPACE PERMISSIONS — TRIBES ADMIN (administration clients)
  // ═══════════════════════════════════════════════════════════════════════════
  | "portal.view"              // View Tribes Admin module
  | "portal.download"          // Download statements and documents
  | "portal.submit"            // Submit requests/data through portal
  
  // ═══════════════════════════════════════════════════════════════════════════
  // LEGACY PERMISSIONS (backward compatibility)
  // ═══════════════════════════════════════════════════════════════════════════
  | "tenant:admin"
  | "tenant:manage_members"
  | "tenant:view_reports"
  | "context:publishing"
  | "context:licensing"
  | "records:create"
  | "records:edit"
  | "records:delete"
  | "records:view"
  | "records:export";

/**
 * Module definitions for route prefixes and permission namespaces
 */
export const MODULES = {
  // ─────────────────────────────────────────────────────────────────────────
  // WORKSPACE MODULES (organization-scoped)
  // ─────────────────────────────────────────────────────────────────────────
  licensing: {
    routePrefix: "/licensing",
    permissionNamespace: "licensing",
    navLabel: "Licensing",
    requiredPermission: "licensing.view" as Permission,
  },
  portal: {
    routePrefix: "/portal",
    permissionNamespace: "portal",
    navLabel: "Tribes Admin",
    requiredPermission: "portal.view" as Permission,
  },
  
  // ─────────────────────────────────────────────────────────────────────────
  // COMPANY-LEVEL MODULE (NOT workspace-scoped)
  // ─────────────────────────────────────────────────────────────────────────
  admin: {
    routePrefix: "/admin",
    permissionNamespace: "platform",
    navLabel: "System Console",
    requiredPermission: "platform:admin" as Permission,
  },
  
  // ─────────────────────────────────────────────────────────────────────────
  // AUDITOR ACCESS (read-only, cross-workspace)
  // ─────────────────────────────────────────────────────────────────────────
  auditor: {
    routePrefix: "/auditor",
    permissionNamespace: "auditor",
    navLabel: "Auditor Access",
    requiredPermission: "auditor:view_logs" as Permission,
  },
  
  // ─────────────────────────────────────────────────────────────────────────
  // HELP WORKSTATION (company-scoped internal tool)
  // ─────────────────────────────────────────────────────────────────────────
  help: {
    routePrefix: "/help-workstation",
    permissionNamespace: "platform",
    navLabel: "Help Workstation",
    requiredPermission: "platform:manage_help" as Permission,
  },
} as const;

interface RoleAccessResult {
  // Core checks
  isPlatformAdmin: boolean;
  isExternalAuditor: boolean;
  isTenantAdmin: boolean;
  isViewer: boolean;
  isMember: boolean;
  
  // Permission checks
  hasPermission: (permission: Permission) => boolean;
  hasAnyPermission: (permissions: Permission[]) => boolean;
  hasAllPermissions: (permissions: Permission[]) => boolean;
  
  // Context access
  canAccessContext: (context: PortalContext) => boolean;
  canAccessAdmin: boolean;
  canAccessAuditor: boolean;
  canAccessHelp: boolean;      // Help backend (capability-based)
  
  // Module access (new first-class modules)
  canAccessLicensing: boolean;
  canAccessPortal: boolean;
  
  // Surface visibility helpers
  shouldRenderSurface: (requiredPermission: Permission) => boolean;
  shouldRenderNavItem: (requiredPermission: Permission) => boolean;
  
  // Read-only mode (for auditors)
  isReadOnlyMode: boolean;
  
  // Navigation visibility
  visibleModules: Array<{ key: string; label: string; path: string }>;
}

/**
 * Role-based access hook for surface pruning
 * 
 * Usage:
 * const { hasPermission, shouldRenderSurface, visibleModules } = useRoleAccess();
 * 
 * // In components:
 * {shouldRenderSurface("licensing.view") && <LicensingSection />}
 */
export function useRoleAccess(): RoleAccessResult {
  const { 
    profile, 
    activeTenant, 
    isPlatformAdmin: authIsPlatformAdmin,
    canAccessContext: authCanAccessContext,
    hasPortalRole 
  } = useAuth();

  const result = useMemo(() => {
    // Core role checks
    const isPlatformAdmin = authIsPlatformAdmin;
    const isExternalAuditor = profile?.platform_role === 'external_auditor' && profile?.status === 'active';
    const isTenantAdmin = hasPortalRole("tenant_admin");
    const isMember = hasPortalRole("tenant_user");
    const isViewer = hasPortalRole("viewer");

    // Determine user's effective role tier for permission resolution
    // Role tiers: platform_admin > external_auditor (read-only) > tenant_admin > tenant_user > viewer
    const isOrgAdmin = isTenantAdmin;
    const isClient = isViewer || (!isPlatformAdmin && !isExternalAuditor && !isTenantAdmin && !isMember);

    // Read-only mode for external auditors (no action buttons)
    const isReadOnlyMode = isExternalAuditor;

    // Permission resolution based on role hierarchy with DEFAULT DENY
    const hasPermission = (permission: Permission): boolean => {
      // Platform admins have all permissions
      if (isPlatformAdmin) return true;

      // External auditors have specific read-only permissions
      if (isExternalAuditor) {
        switch (permission) {
          case "auditor:view_logs":
          case "auditor:view_licensing":
          case "auditor:view_agreements":
          case "auditor:view_disclosures":
          case "records:view":
            return true;
          default:
            return false; // External auditors can ONLY view, not create/edit/delete
        }
      }

      switch (permission) {
        // ═══════════════════════════════════════════════════════════════════════
        // PLATFORM-LEVEL PERMISSIONS — platform_admin only
        // ═══════════════════════════════════════════════════════════════════════
        case "platform:admin":
        case "platform:manage_users":
        case "platform:manage_tenants":
        case "platform:view_audit_logs":
        case "platform:manage_security":
          return false; // DEFAULT DENY for non-admins
        
        // ═══════════════════════════════════════════════════════════════════════
        // HELP BACKEND PERMISSION — capability-based
        // Requires platform_user role + can_manage_help capability
        // ═══════════════════════════════════════════════════════════════════════
        case "platform:manage_help":
          // This is checked via useHelpAccess hook for real-time capability check
          // Here we only allow if user has internal role (not external_auditor)
          return profile?.platform_role === 'platform_user' && (profile as any)?.can_manage_help === true;

        // ═══════════════════════════════════════════════════════════════════════
        // EXTERNAL AUDITOR PERMISSIONS — read-only
        // ═══════════════════════════════════════════════════════════════════════
        case "auditor:view_logs":
        case "auditor:view_licensing":
        case "auditor:view_agreements":
        case "auditor:view_disclosures":
          return false; // Only external auditors and platform admins

        // ═══════════════════════════════════════════════════════════════════════
        // TENANT-LEVEL PERMISSIONS
        // ═══════════════════════════════════════════════════════════════════════
        case "tenant:admin":
        case "tenant:manage_members":
          return isOrgAdmin;
        
        case "tenant:view_reports":
          return isOrgAdmin || isMember;

        // ═══════════════════════════════════════════════════════════════════════
        // CONTEXT ACCESS (legacy compatibility)
        // ═══════════════════════════════════════════════════════════════════════
        case "context:publishing":
          return authCanAccessContext("publishing");
        case "context:licensing":
          return authCanAccessContext("licensing");

        // ═══════════════════════════════════════════════════════════════════════
        // RECORD OPERATIONS
        // ═══════════════════════════════════════════════════════════════════════
        case "records:create":
        case "records:edit":
        case "records:delete":
          return isOrgAdmin || isMember;
        
        case "records:view":
        case "records:export":
          return isOrgAdmin || isMember || isViewer;

        // ═══════════════════════════════════════════════════════════════════════
        // LICENSING MODULE PERMISSIONS — DEFAULT DENY
        // ═══════════════════════════════════════════════════════════════════════
        case "licensing.view":
          // Platform Admin: YES
          // Org Admin: YES (if context allowed)
          // Client: NO
          return isOrgAdmin && authCanAccessContext("licensing");
        
        case "licensing.manage":
          // Platform Admin: YES
          // Org Admin: YES (if context allowed)
          // Client: NO
          return isOrgAdmin && authCanAccessContext("licensing");
        
        case "licensing.approve":
          // Platform Admin: YES
          // Org Admin: NO (requires platform-level approval)
          // Client: NO
          return false; // Only platform admins

        // ═══════════════════════════════════════════════════════════════════════
        // CLIENT PORTAL PERMISSIONS — DEFAULT DENY
        // ═══════════════════════════════════════════════════════════════════════
        case "portal.view":
          // Platform Admin: YES
          // Org Admin: YES (if context allowed)
          // Client: YES (if context allowed)
          return (isOrgAdmin || isMember || isViewer) && authCanAccessContext("publishing");
        
        case "portal.download":
          // Platform Admin: YES
          // Org Admin: YES
          // Client: YES
          return (isOrgAdmin || isMember || isViewer) && authCanAccessContext("publishing");
        
        case "portal.submit":
          // Platform Admin: YES
          // Org Admin: NO (clients submit, admins review)
          // Client: NO (readonly client role)
          return isMember && authCanAccessContext("publishing");

        default:
          return false; // DEFAULT DENY
      }
    };

    const hasAnyPermission = (permissions: Permission[]): boolean => {
      return permissions.some(hasPermission);
    };

    const hasAllPermissions = (permissions: Permission[]): boolean => {
      return permissions.every(hasPermission);
    };

    const canAccessContext = authCanAccessContext;
    const canAccessAdmin = isPlatformAdmin;
    const canAccessAuditor = isExternalAuditor || isPlatformAdmin;
    
    // First-class module access
    const canAccessLicensing = hasPermission("licensing.view");
    const canAccessPortal = hasPermission("portal.view");
    
    // Help backend access (capability-based, company-scoped)
    const canAccessHelp = hasPermission("platform:manage_help");

    // Surface visibility: if no permission, surface is NOT rendered
    // No disabled buttons, no placeholders
    const shouldRenderSurface = (requiredPermission: Permission): boolean => {
      return hasPermission(requiredPermission);
    };

    const shouldRenderNavItem = (requiredPermission: Permission): boolean => {
      return hasPermission(requiredPermission);
    };

    // Build visible modules for navigation
    const visibleModules: Array<{ key: string; label: string; path: string }> = [];
    
    // External auditors only see their audit access
    if (isExternalAuditor) {
      visibleModules.push({
        key: "auditor",
        label: MODULES.auditor.navLabel,
        path: MODULES.auditor.routePrefix,
      });
    } else {
      if (canAccessPortal) {
        visibleModules.push({
          key: "portal",
          label: MODULES.portal.navLabel,
          path: MODULES.portal.routePrefix,
        });
      }
      
      if (canAccessLicensing) {
        visibleModules.push({
          key: "licensing",
          label: MODULES.licensing.navLabel,
          path: MODULES.licensing.routePrefix,
        });
      }
    }
    
    // Administration is only shown in dropdown, not primary nav
    // Platform admins see it in account menu

    return {
      isPlatformAdmin,
      isExternalAuditor,
      isTenantAdmin,
      isViewer,
      isMember,
      hasPermission,
      hasAnyPermission,
      hasAllPermissions,
      canAccessContext,
      canAccessAdmin,
      canAccessAuditor,
      canAccessHelp,
      canAccessLicensing,
      canAccessPortal,
      shouldRenderSurface,
      shouldRenderNavItem,
      isReadOnlyMode,
      visibleModules,
    };
  }, [
    authIsPlatformAdmin,
    hasPortalRole,
    authCanAccessContext,
    activeTenant,
    profile,
  ]);

  return result;
}

/**
 * Higher-order component for role-gated surfaces
 * 
 * Usage:
 * const AdminOnlySection = withPermission(MySection, "platform:admin");
 */
export function withPermission<P extends object>(
  Component: React.ComponentType<P>,
  requiredPermission: Permission
): React.FC<P> {
  return function PermissionGated(props: P) {
    const { shouldRenderSurface } = useRoleAccess();
    
    if (!shouldRenderSurface(requiredPermission)) {
      return null;
    }
    
    return <Component {...props} />;
  };
}
