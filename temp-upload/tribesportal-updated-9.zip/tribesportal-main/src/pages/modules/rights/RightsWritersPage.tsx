import { useState, useEffect } from "react";
import { Plus, Search, Pencil } from "lucide-react";

import {
  AppPageContainer,
  AppSection,
  AppButton,
  AppTable,
  AppTableHeader,
  AppTableBody,
  AppTableRow,
  AppTableHead,
  AppTableCell,
  AppTableEmpty,
  AppPagination,
} from "@/components/app-ui";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

/**
 * RIGHTS WRITERS PAGE — Staff Management View
 * 
 * Master registry of all writers/composers/interested parties.
 * Displays: Name, PRO, IPI Number
 */

const ITEMS_PER_PAGE = 50;

interface Writer {
  id: string;
  name: string;
  first_name: string | null;
  last_name: string | null;
  pro: string | null;
  ipi_number: string | null;
  cae_number: string | null;
  email: string | null;
  created_at: string;
}

const PRO_OPTIONS = [
  { value: "", label: "Not specified" },
  { value: "ASCAP", label: "ASCAP" },
  { value: "BMI", label: "BMI" },
  { value: "SESAC", label: "SESAC" },
  { value: "GMR", label: "GMR" },
  { value: "SOCAN", label: "SOCAN" },
  { value: "PRS", label: "PRS" },
  { value: "APRA", label: "APRA" },
  { value: "GEMA", label: "GEMA" },
  { value: "SACEM", label: "SACEM" },
  { value: "NS", label: "NS (Not Specified)" },
];

export default function RightsWritersPage() {
  const [writers, setWriters] = useState<Writer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  
  // Edit sheet state
  const [editSheetOpen, setEditSheetOpen] = useState(false);
  const [editingWriter, setEditingWriter] = useState<Writer | null>(null);
  const [saving, setSaving] = useState(false);
  
  // Form state
  const [formData, setFormData] = useState({
    name: "",
    first_name: "",
    last_name: "",
    pro: "",
    ipi_number: "",
    email: "",
  });

  // Fetch writers from Supabase
  const fetchWriters = async () => {
    setLoading(true);
    
    try {
      // Build count query
      let countQuery = supabase
        .from('writers')
        .select('*', { count: 'exact', head: true });
      
      if (searchQuery.trim()) {
        countQuery = countQuery.ilike('name', `%${searchQuery.trim()}%`);
      }
      
      const { count } = await countQuery;
      setTotalCount(count || 0);

      // Fetch paginated data
      const from = (currentPage - 1) * ITEMS_PER_PAGE;
      const to = from + ITEMS_PER_PAGE - 1;

      let query = supabase
        .from('writers')
        .select('id, name, first_name, last_name, pro, ipi_number, cae_number, email, created_at')
        .order('name', { ascending: true })
        .range(from, to);

      if (searchQuery.trim()) {
        query = query.ilike('name', `%${searchQuery.trim()}%`);
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching writers:', error);
        return;
      }

      setWriters(data || []);
    } catch (err) {
      console.error('Error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWriters();
  }, [currentPage, searchQuery]);

  const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    setCurrentPage(1);
  };

  const handleEditClick = (writer: Writer, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingWriter(writer);
    setFormData({
      name: writer.name || "",
      first_name: writer.first_name || "",
      last_name: writer.last_name || "",
      pro: writer.pro || "",
      ipi_number: writer.ipi_number || "",
      email: writer.email || "",
    });
    setEditSheetOpen(true);
  };

  const handleSave = async () => {
    if (!editingWriter) return;
    
    setSaving(true);
    try {
      const { error } = await supabase
        .from('writers')
        .update({
          name: formData.name.trim(),
          first_name: formData.first_name.trim() || null,
          last_name: formData.last_name.trim() || null,
          pro: formData.pro || null,
          ipi_number: formData.ipi_number.trim() || null,
          email: formData.email.trim() || null,
        })
        .eq('id', editingWriter.id);

      if (error) throw error;

      toast.success('Writer updated');
      setEditSheetOpen(false);
      fetchWriters();
    } catch (err) {
      console.error('Error updating writer:', err);
      toast.error('Failed to update writer');
    } finally {
      setSaving(false);
    }
  };

  const handleAddNew = () => {
    setEditingWriter(null);
    setFormData({
      name: "",
      first_name: "",
      last_name: "",
      pro: "",
      ipi_number: "",
      email: "",
    });
    setEditSheetOpen(true);
  };

  const handleCreate = async () => {
    if (!formData.name.trim()) {
      toast.error('Name is required');
      return;
    }
    
    setSaving(true);
    try {
      const { error } = await supabase
        .from('writers')
        .insert({
          name: formData.name.trim(),
          first_name: formData.first_name.trim() || null,
          last_name: formData.last_name.trim() || null,
          pro: formData.pro || null,
          ipi_number: formData.ipi_number.trim() || null,
          email: formData.email.trim() || null,
        });

      if (error) throw error;

      toast.success('Writer added');
      setEditSheetOpen(false);
      fetchWriters();
    } catch (err) {
      console.error('Error creating writer:', err);
      toast.error('Failed to add writer');
    } finally {
      setSaving(false);
    }
  };

  return (
    <AppPageContainer maxWidth="xl">
      {/* Header Row: Title + Action */}
      <div className="flex items-center justify-between mb-3">
        <h1 className="text-lg font-semibold tracking-tight">Writers</h1>
        <AppButton
          intent="secondary"
          size="sm"
          onClick={handleAddNew}
        >
          <Plus className="h-4 w-4" />
          Add Writer
        </AppButton>
      </div>

      {/* Search */}
      <div className="mb-4">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search by name..."
            value={searchQuery}
            onChange={handleSearchChange}
            className="w-full h-9 pl-9 pr-3 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
      </div>

      {/* Stats */}
      <div className="flex items-center justify-end mb-3">
        <div className="text-[13px] text-muted-foreground">
          {totalCount.toLocaleString()} writers
        </div>
      </div>

      {/* Table */}
      <AppSection>
        <AppTable columns={["45%", "20%", "25%", "10%"]}>
          <AppTableHeader>
            <AppTableRow>
              <AppTableHead>NAME</AppTableHead>
              <AppTableHead>PRO</AppTableHead>
              <AppTableHead>IPI NUMBER</AppTableHead>
              <AppTableHead align="center"></AppTableHead>
            </AppTableRow>
          </AppTableHeader>
          <AppTableBody>
            {loading ? (
              <AppTableRow>
                <AppTableCell colSpan={4}>
                  <div className="flex items-center justify-center py-8 text-muted-foreground">
                    Loading...
                  </div>
                </AppTableCell>
              </AppTableRow>
            ) : writers.length === 0 ? (
              <AppTableEmpty
                colSpan={4}
                message={searchQuery ? "No writers match your search" : "No writers in the system"}
              />
            ) : (
              writers.map((writer) => (
                <AppTableRow key={writer.id}>
                  <AppTableCell className="font-medium">{writer.name}</AppTableCell>
                  <AppTableCell muted>{writer.pro || "—"}</AppTableCell>
                  <AppTableCell muted>{writer.ipi_number || writer.cae_number || "—"}</AppTableCell>
                  <AppTableCell align="center">
                    <button
                      onClick={(e) => handleEditClick(writer, e)}
                      className="p-1.5 rounded hover:bg-muted transition-colors"
                    >
                      <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
                    </button>
                  </AppTableCell>
                </AppTableRow>
              ))
            )}
          </AppTableBody>
        </AppTable>

        {/* Pagination */}
        {totalPages > 1 && (
          <AppPagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
          />
        )}
      </AppSection>

      {/* Edit/Add Writer Sheet */}
      <Sheet open={editSheetOpen} onOpenChange={setEditSheetOpen}>
        <SheetContent>
          <SheetHeader>
            <SheetTitle>{editingWriter ? 'Edit Writer' : 'Add Writer'}</SheetTitle>
          </SheetHeader>
          
          <div className="mt-6 space-y-4">
            <div>
              <label className="block text-[13px] font-medium mb-1.5">Name *</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full h-9 px-3 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                placeholder="Full name"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[13px] font-medium mb-1.5">First Name</label>
                <input
                  type="text"
                  value={formData.first_name}
                  onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                  className="w-full h-9 px-3 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
              <div>
                <label className="block text-[13px] font-medium mb-1.5">Last Name</label>
                <input
                  type="text"
                  value={formData.last_name}
                  onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                  className="w-full h-9 px-3 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-[13px] font-medium mb-1.5">PRO</label>
              <select
                value={formData.pro}
                onChange={(e) => setFormData({ ...formData, pro: e.target.value })}
                className="w-full h-9 px-3 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
              >
                {PRO_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-[13px] font-medium mb-1.5">IPI Number</label>
              <input
                type="text"
                value={formData.ipi_number}
                onChange={(e) => setFormData({ ...formData, ipi_number: e.target.value })}
                className="w-full h-9 px-3 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                placeholder="e.g., 00123456789"
              />
            </div>
            
            <div>
              <label className="block text-[13px] font-medium mb-1.5">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full h-9 px-3 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                placeholder="writer@example.com"
              />
            </div>
          </div>
          
          <div className="mt-8 flex gap-3">
            <AppButton
              intent="primary"
              className="flex-1"
              onClick={editingWriter ? handleSave : handleCreate}
              disabled={saving}
            >
              {saving ? 'Saving...' : (editingWriter ? 'Save Changes' : 'Add Writer')}
            </AppButton>
            <AppButton
              intent="secondary"
              onClick={() => setEditSheetOpen(false)}
              disabled={saving}
            >
              Cancel
            </AppButton>
          </div>
        </SheetContent>
      </Sheet>
    </AppPageContainer>
  );
}
