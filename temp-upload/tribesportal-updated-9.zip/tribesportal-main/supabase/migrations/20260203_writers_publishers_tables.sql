-- ============================================
-- TRIBES RIGHTS MANAGEMENT: WRITERS & PUBLISHERS TABLES
-- 
-- Canonical registry tables for interested parties.
-- Songs reference these tables for ownership/splits.
-- ============================================

-- ============================================
-- WRITERS TABLE
-- Songwriters, composers, lyricists
-- ============================================
CREATE TABLE IF NOT EXISTS public.writers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Identity
  name text NOT NULL,                    -- Display name (e.g., "John Smith")
  legal_name text,                       -- Full legal name if different
  first_name text,
  middle_name text,
  last_name text,
  
  -- Industry identifiers
  ipi_number text,                       -- IPI Name Number (9-11 digits)
  cae_number text,                       -- CAE/IPI Base Number (legacy)
  isni text,                             -- International Standard Name Identifier
  
  -- PRO affiliation
  pro text,                              -- Performance Rights Org (ASCAP, BMI, SESAC, GMR, NS)
  pro_member_id text,                    -- PRO membership number
  mechanical_society text,               -- Mechanical rights society
  mechanical_society_id text,
  
  -- Contact (optional)
  email text,
  phone text,
  
  -- Status
  is_controlled boolean DEFAULT false,   -- Under Tribes administration
  is_active boolean DEFAULT true,
  
  -- Metadata
  territories text[] DEFAULT '{WW}',     -- Territory coverage
  notes text,
  metadata jsonb DEFAULT '{}',
  
  -- Audit
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id),
  
  -- Constraints
  CONSTRAINT writers_name_not_empty CHECK (trim(name) <> '')
);

-- ============================================
-- PUBLISHERS TABLE  
-- Publishers, administrators, sub-publishers
-- ============================================
CREATE TABLE IF NOT EXISTS public.publishers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Identity
  name text NOT NULL,                    -- Company/entity name
  legal_name text,                       -- Full legal entity name
  dba_name text,                         -- "Doing business as" name
  
  -- Industry identifiers
  ipi_number text,                       -- IPI Name Number
  isni text,                             -- International Standard Name Identifier
  
  -- PRO affiliation
  pro text,                              -- Primary PRO affiliation
  pro_member_id text,
  mechanical_society text,
  mechanical_society_id text,
  
  -- Publisher type
  publisher_type text DEFAULT 'publisher' 
    CHECK (publisher_type IN ('publisher', 'administrator', 'sub_publisher', 'original_publisher')),
  
  -- Contact
  contact_name text,
  email text,
  phone text,
  address_line1 text,
  address_line2 text,
  city text,
  state text,
  postal_code text,
  country text DEFAULT 'US',
  
  -- Status
  is_controlled boolean DEFAULT false,   -- Under Tribes administration
  is_active boolean DEFAULT true,
  
  -- Metadata
  territories text[] DEFAULT '{WW}',
  notes text,
  metadata jsonb DEFAULT '{}',
  
  -- Audit
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id),
  
  -- Constraints
  CONSTRAINT publishers_name_not_empty CHECK (trim(name) <> '')
);

-- ============================================
-- SONGS TABLE
-- Master song/composition registry
-- ============================================
CREATE TABLE IF NOT EXISTS public.songs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Core identification
  title text NOT NULL,
  alternate_titles text[],               -- AKAs, translated titles
  
  -- Industry identifiers
  iswc text,                             -- International Standard Musical Work Code
  
  -- Metadata
  language text,
  genre text,
  release_year integer,
  duration_seconds integer,
  
  -- Status
  status text DEFAULT 'pending'
    CHECK (status IN ('draft', 'pending', 'active', 'inactive', 'disputed', 'archived')),
  is_active boolean DEFAULT true,
  
  -- Copyright
  copyright_year integer,
  copyright_owner text,
  
  -- Extended metadata (lyrics, notes, etc.)
  metadata jsonb DEFAULT '{}',
  
  -- Audit
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id),
  
  -- Constraints
  CONSTRAINT songs_title_not_empty CHECK (trim(title) <> '')
);

-- ============================================
-- SONG_WRITERS TABLE (Junction)
-- Links songs to writers with ownership %
-- ============================================
CREATE TABLE IF NOT EXISTS public.song_writers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  song_id uuid NOT NULL REFERENCES public.songs(id) ON DELETE CASCADE,
  writer_id uuid NOT NULL REFERENCES public.writers(id) ON DELETE RESTRICT,
  
  -- Ownership
  ownership_percentage numeric(5,2) NOT NULL DEFAULT 0
    CHECK (ownership_percentage >= 0 AND ownership_percentage <= 100),
  
  -- Role specifics
  writer_role text DEFAULT 'writer'
    CHECK (writer_role IN ('writer', 'composer', 'lyricist', 'arranger', 'adapter', 'translator')),
  
  -- PRO share type
  share_type text DEFAULT 'writer'
    CHECK (share_type IN ('writer', 'publisher')),
  
  -- Effective dates (for historical tracking)
  effective_from date,
  effective_to date,
  
  -- Audit
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  -- Prevent duplicate writer on same song
  CONSTRAINT song_writers_unique UNIQUE (song_id, writer_id, share_type)
);

-- ============================================
-- SONG_PUBLISHERS TABLE (Junction)
-- Links songs to publishers with ownership %
-- ============================================
CREATE TABLE IF NOT EXISTS public.song_publishers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  song_id uuid NOT NULL REFERENCES public.songs(id) ON DELETE CASCADE,
  publisher_id uuid NOT NULL REFERENCES public.publishers(id) ON DELETE RESTRICT,
  
  -- Ownership
  ownership_percentage numeric(5,2) NOT NULL DEFAULT 0
    CHECK (ownership_percentage >= 0 AND ownership_percentage <= 100),
  
  -- Role
  publisher_role text DEFAULT 'publisher'
    CHECK (publisher_role IN ('publisher', 'administrator', 'sub_publisher', 'original_publisher')),
  
  -- Territory-specific (optional)
  territory text DEFAULT 'WW',
  
  -- Chain of title reference
  administered_by uuid REFERENCES public.publishers(id),
  
  -- Effective dates
  effective_from date,
  effective_to date,
  
  -- Audit
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  -- Prevent duplicate publisher on same song for same territory
  CONSTRAINT song_publishers_unique UNIQUE (song_id, publisher_id, territory)
);

-- ============================================
-- ENABLE ROW LEVEL SECURITY
-- ============================================
ALTER TABLE public.writers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.publishers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.songs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.song_writers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.song_publishers ENABLE ROW LEVEL SECURITY;

-- ============================================
-- RLS POLICIES - Writers
-- ============================================
CREATE POLICY "writers_select" ON public.writers 
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "writers_insert" ON public.writers 
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "writers_update" ON public.writers 
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "writers_delete" ON public.writers 
  FOR DELETE TO authenticated USING (true);

-- ============================================
-- RLS POLICIES - Publishers
-- ============================================
CREATE POLICY "publishers_select" ON public.publishers 
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "publishers_insert" ON public.publishers 
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "publishers_update" ON public.publishers 
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "publishers_delete" ON public.publishers 
  FOR DELETE TO authenticated USING (true);

-- ============================================
-- RLS POLICIES - Songs
-- ============================================
CREATE POLICY "songs_select" ON public.songs 
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "songs_insert" ON public.songs 
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "songs_update" ON public.songs 
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "songs_delete" ON public.songs 
  FOR DELETE TO authenticated USING (true);

-- ============================================
-- RLS POLICIES - Song Writers (Junction)
-- ============================================
CREATE POLICY "song_writers_select" ON public.song_writers 
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "song_writers_insert" ON public.song_writers 
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "song_writers_update" ON public.song_writers 
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "song_writers_delete" ON public.song_writers 
  FOR DELETE TO authenticated USING (true);

-- ============================================
-- RLS POLICIES - Song Publishers (Junction)
-- ============================================
CREATE POLICY "song_publishers_select" ON public.song_publishers 
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "song_publishers_insert" ON public.song_publishers 
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "song_publishers_update" ON public.song_publishers 
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "song_publishers_delete" ON public.song_publishers 
  FOR DELETE TO authenticated USING (true);

-- ============================================
-- INDEXES
-- ============================================
CREATE INDEX idx_writers_name ON public.writers(name);
CREATE INDEX idx_writers_pro ON public.writers(pro);
CREATE INDEX idx_writers_ipi ON public.writers(ipi_number);
CREATE INDEX idx_writers_controlled ON public.writers(is_controlled);

CREATE INDEX idx_publishers_name ON public.publishers(name);
CREATE INDEX idx_publishers_pro ON public.publishers(pro);
CREATE INDEX idx_publishers_type ON public.publishers(publisher_type);
CREATE INDEX idx_publishers_controlled ON public.publishers(is_controlled);

CREATE INDEX idx_songs_title ON public.songs(title);
CREATE INDEX idx_songs_iswc ON public.songs(iswc);
CREATE INDEX idx_songs_status ON public.songs(status);

CREATE INDEX idx_song_writers_song ON public.song_writers(song_id);
CREATE INDEX idx_song_writers_writer ON public.song_writers(writer_id);

CREATE INDEX idx_song_publishers_song ON public.song_publishers(song_id);
CREATE INDEX idx_song_publishers_publisher ON public.song_publishers(publisher_id);

-- ============================================
-- TRIGGERS
-- ============================================
CREATE TRIGGER update_writers_updated_at
  BEFORE UPDATE ON public.writers
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_publishers_updated_at
  BEFORE UPDATE ON public.publishers
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_songs_updated_at
  BEFORE UPDATE ON public.songs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_song_writers_updated_at
  BEFORE UPDATE ON public.song_writers
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_song_publishers_updated_at
  BEFORE UPDATE ON public.song_publishers
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
